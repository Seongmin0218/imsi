//src/constants/regex.ts
export const NICKNAME_REGEX = /^[A-Za-z0-9가-힣]{1,5}$/;

export const PASSWORD_REGEX = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;