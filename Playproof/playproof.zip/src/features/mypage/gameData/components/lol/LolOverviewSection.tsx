import type {
  DashboardTabKey,
  LolAggregateStats,
  LolLinkedProfile,
  LolMatchItem,
  PaginationState,
} from "@/features/mypage/gameData/types/gameDataTypes";
import { FilterTabs } from "../FilterTabs";
import { LolAccountHeaderCard } from "./LolAccountHeaderCard";
import { LolStatsCardsRow } from "./LolStatsCardRow";
import { MatchListSection } from "./MatchListSection";

type Props = {
  linkedProfile: LolLinkedProfile;
  aggregate: LolAggregateStats;
  matches: LolMatchItem[];
  pagination: PaginationState;
  activeTab: DashboardTabKey;
  onChangeTab: (tab: DashboardTabKey) => void;
};

export const LolOverviewSection = (props: Props) => {
  const { linkedProfile, aggregate, matches, pagination, activeTab, onChangeTab } = props;

  return (
    <div className="space-y-4">
      <LolAccountHeaderCard profile={linkedProfile} />
      <LolStatsCardsRow stats={aggregate} />
      <FilterTabs activeTab={activeTab} onChangeTab={onChangeTab} />
      <MatchListSection matches={matches} pagination={pagination} activeTab={activeTab} />
    </div>
  );
};