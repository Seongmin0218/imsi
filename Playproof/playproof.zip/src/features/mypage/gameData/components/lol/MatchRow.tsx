import { Card } from "@/components/ui/Card";
import type { LolMatchItem } from "@/features/mypage/gameData/types/gameDataTypes";

type Props = { match: LolMatchItem };

export const MatchRow = ({ match }: Props) => {
  const resultLabel = match.result === "win" ? "승리" : "패배";

  return (
    <Card className="px-6 py-4">
      <div className="grid grid-cols-1 items-center gap-4 md:grid-cols-[120px_1fr_220px]">
        <div className="flex items-center gap-3">
          <div className="text-sm font-semibold text-gray-900">{resultLabel}</div>
          <div className="text-[11px] text-gray-500">{match.durationText}</div>
        </div>

        <div className="text-center">
          <div className="text-xl font-semibold text-gray-900">{match.kdaText}</div>
          <div className="mt-1 text-[11px] text-gray-500">{match.kdaRatioText}</div>
        </div>

        <div className="flex items-center justify-end gap-3">
          <div className="flex flex-wrap items-center justify-end gap-1">
            {match.pills.slice(0, 4).map((p) => (
              <span key={p} className="rounded-md border border-gray-200 bg-white px-2 py-1 text-[10px] text-gray-600">
                {p}
              </span>
            ))}
          </div>

          <div className="grid grid-cols-4 gap-1">
            {Array.from({ length: match.itemsCount }).map((_, idx) => (
              <div key={idx} className="h-6 w-6 rounded bg-gray-200" />
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
};