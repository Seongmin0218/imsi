import type { PaginationState } from "@/features/mypage/gameData/types/gameDataTypes";

type Props = { pagination: PaginationState };

export const PaginationBar = ({ pagination }: Props) => {
  const { page, totalPages } = pagination;
  const pages = Array.from({ length: totalPages }).map((_, i) => i + 1);

  return (
    <div className="flex items-center justify-between pt-2">
      <div className="text-xs text-gray-500">페이지당 보기: {pagination.pageSize}</div>

      <div className="flex items-center gap-2">
        {pages.slice(0, 12).map((p) => (
          <button
            key={p}
            type="button"
            className={["h-8 w-8 rounded-md text-xs", p === page ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"].join(
              " "
            )}
          >
            {p}
          </button>
        ))}
        <button type="button" className="h-8 rounded-md bg-gray-100 px-3 text-xs text-gray-700 hover:bg-gray-200">
          다음
        </button>
      </div>
    </div>
  );
};