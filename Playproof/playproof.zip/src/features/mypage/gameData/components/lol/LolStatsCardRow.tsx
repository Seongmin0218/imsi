import { Card } from "@/components/ui/Card";
import type { LolAggregateStats } from "@/features/mypage/gameData/types/gameDataTypes";

type Props = { stats: LolAggregateStats };

export const LolStatsCardsRow = ({ stats }: Props) => {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      <Card className="p-6">
        <div className="flex items-center gap-4">
          <div className="h-16 w-16 rounded-full bg-gray-100" />
          <div>
            <div className="text-[11px] text-gray-500">
              {stats.wins}w {stats.losses}l
            </div>
            <div className="mt-2 text-2xl font-semibold">{stats.winRatePercent}%</div>
            <div className="mt-1 text-xs text-gray-500">
              {stats.wins}w {stats.losses}l
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <div className="text-[11px] text-gray-500">평균 K/D/A</div>
        <div className="mt-2 text-2xl font-semibold">{stats.avgKdaRatio.toFixed(2)}</div>
        <div className="mt-1 text-xs text-gray-500">
          {stats.avgKills.toFixed(1)} / {stats.avgDeaths.toFixed(1)} / {stats.avgAssists.toFixed(1)}
        </div>
      </Card>

      <Card className="p-6">
        <div className="text-[11px] text-gray-500">모스트 챔피언</div>
        <div className="mt-4 flex items-center gap-4">
          {stats.mostChampions.slice(0, 3).map((c) => (
            <div key={c.name} className="flex flex-col items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-gray-200" />
              <div className="text-[11px] text-gray-600">{c.name}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};