import type { GameKey, LinkedAccount } from "../types/gameDataTypes";
import { ConnectAccountCard } from "./ConnectAccountCard";
import { GameAccountCard } from "./GameAccountCard";

type Props = {
  accounts: LinkedAccount[];
  selectedGame: GameKey | null;
  onSelectGame: (game: GameKey) => void;
};

export const LinkedAccountsRow = ({ accounts, selectedGame, onSelectGame }: Props) => {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-[1fr_320px]">
      <div className="flex items-stretch gap-4 overflow-x-auto">
        {accounts.map((a) => (
          <div key={a.game} className="w-[400px] min-w-[400px] flex-shrink-0">
            <GameAccountCard
              account={a}
              selected={selectedGame === a.game}
              onClick={() => onSelectGame(a.game)}
            />
          </div>
        ))}
      </div>

      <div className="w-full">
        <ConnectAccountCard />
      </div>
    </div>
  );
};