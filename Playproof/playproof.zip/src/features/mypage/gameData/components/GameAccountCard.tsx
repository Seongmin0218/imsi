import { Card } from "@/components/ui/Card";
import type { LinkedAccount } from "../types/gameDataTypes";

type Props = {
  account: LinkedAccount;
  selected: boolean;
  onClick: () => void;
};

export const GameAccountCard = ({ account, selected, onClick }: Props) => {
  const items = account.accounts.slice(0, 3);
  const colsClass =
    items.length >= 3 ? "grid-cols-3" : items.length === 2 ? "grid-cols-2" : "grid-cols-1";

  return (
    <button
      type="button"
      onClick={onClick}
      className="h-full w-full text-left"
    >
      <Card
        className={[
          "h-full p-6 transition",
          selected ? "border-gray-400" : "border-gray-200 hover:border-gray-300",
        ].join(" ")}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-base font-semibold text-gray-900">{account.title}</div>
            <div className="mt-1 text-xs text-gray-500">#게임 내 닉네임</div>
          </div>

          <div className="text-gray-500" aria-hidden>
            ↻
          </div>
        </div>

        <div className="mt-4 rounded-xl bg-gray-100 px-6 py-4">
          <div className={["grid gap-6 text-center", colsClass].join(" ")}>
            {items.map((row, idx) => (
              <div key={`${row.label}-${idx}`} className="space-y-2">
                <div className="text-xs text-gray-500">{row.label}</div>
                <div className="text-sm font-semibold text-gray-900">{row.value}</div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </button>
  );
};