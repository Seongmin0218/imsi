
import axios from "axios";

/**
 * Riot API 프록시 전용 axios 인스턴스
 * - Riot API 직접 호출 ❌
 * - Vercel Functions (/api/riot/*)만 사용 ✅
 */
const api = axios.create({
  baseURL: "/api/riot",
  timeout: 10_000,
});

/* =========================
 * DTO (이 프로젝트에서 실제로 쓰는 최소 타입만)
 * ========================= */
export type AccountDto = {
  puuid: string;
  gameName: string;
  tagLine: string;
};

export type SummonerDto = {
  id: string; // encryptedSummonerId
  profileIconId?: number;
  summonerLevel?: number;
};

export type LeagueEntryDto = {
  queueType: string;
  tier: string;
  rank: string;
  wins: number;
  losses: number;
};

export type MatchDto = {
  metadata: { matchId: string };
  info: {
    gameDuration: number;
    participants: Array<{
      puuid: string;
      win: boolean;
      kills: number;
      deaths: number;
      assists: number;
      championName: string;
      teamPosition?: string;
      item0: number;
      item1: number;
      item2: number;
      item3: number;
      item4: number;
      item5: number;
      item6: number;
    }>;
  };
};

const parseJsonMaybe = <T,>(value: unknown): T => {
  // Vercel 함수가 res.send(text)로 내려주는 케이스 방어
  if (typeof value === "string") {
    try {
      return JSON.parse(value) as T;
    } catch {
      return value as T;
    }
  }
  return value as T;
};

/* =========================
 * Account-V1
 * Riot ID → PUUID
 * ========================= */
async function getPuuidByRiotId(gameName: string, tagLine: string): Promise<AccountDto> {
  const { data } = await api.get("/account", { params: { gameName, tagLine } });
  return parseJsonMaybe<AccountDto>(data);
}

/**
 * ✅ 구버전 호환 alias
 */
async function getAccountByRiotId(gameName: string, tagLine: string) {
  return getPuuidByRiotId(gameName, tagLine);
}

/* =========================
 * Summoner-V4
 * PUUID → Summoner Profile
 * ========================= */
async function getSummonerByPuuid(puuid: string): Promise<SummonerDto> {
  const { data } = await api.get("/summoner", { params: { puuid } });
  return parseJsonMaybe<SummonerDto>(data);
}

/* =========================
 * League-V4
 * SummonerId(encryptedSummonerId) → league entries
 * ========================= */
async function getLeagueEntriesBySummonerId(
  encryptedSummonerId: string | undefined | null
): Promise<LeagueEntryDto[]> {
  // ✅ summonerId가 없으면 호출 자체를 하지 않는다 (400 방지)
  if (!encryptedSummonerId) return [];

  const res = await api.get("/league", {
    params: { summonerId: encryptedSummonerId },
    validateStatus: () => true, // 403도 data를 받게
  });

  // League-V4는 403이 자주 발생(키 정책/권한). 여기서는 graceful fallback.
  if (res.status === 403) return [];

  const parsed = parseJsonMaybe<unknown>(res.data);
  return (Array.isArray(parsed) ? parsed : []) as LeagueEntryDto[];
}

/* =========================
 * Match-V5
 * PUUID → Match IDs
 * ========================= */
async function getMatchIdsByPuuid(
  puuid: string,
  options?: { start?: number; count?: number }
): Promise<string[]> {
  const { data } = await api.get("/match-ids", {
    params: {
      puuid,
      start: options?.start ?? 0,
      count: options?.count ?? 10,
    },
  });
  return parseJsonMaybe<string[]>(data);
}

/* =========================
 * Match-V5
 * Match ID → Match Detail
 * ========================= */
async function getMatchDetail(matchId: string): Promise<MatchDto> {
  const { data } = await api.get("/match", { params: { matchId } });
  return parseJsonMaybe<MatchDto>(data);
}

export const riotApi = {
  // 신규
  getPuuidByRiotId,
  getSummonerByPuuid,
  getLeagueEntriesBySummonerId,
  getMatchIdsByPuuid,
  getMatchDetail,

  // 구버전 호환
  getAccountByRiotId,
};