import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type {
  DashboardTabKey,
  GameDataDashboardData,
  GameKey,
  LinkedAccount,
} from "../types/gameDataTypes";
import { MOCK_GAME_DATA_DASHBOARD } from "../data/mock";
import { riotApi } from "../api/riotApi";
import {
  buildLolAggregateStats,
  buildLolLinkedProfile,
  buildLolMatchList,
} from "../utils/lolViewModel";

type EmptyView = { kind: "empty" };
type PlaceholderView = { kind: "placeholder"; title: string; subtitle: string };
type LolLoadingView = { kind: "lolLoading" };
type LolErrorView = { kind: "lolError"; message: string };
type LolView = { kind: "lol"; lol: GameDataDashboardData["lol"] };
type DashboardView =
  | EmptyView
  | PlaceholderView
  | LolLoadingView
  | LolErrorView
  | LolView;

const findLolAccount = (accounts: LinkedAccount[]) =>
  accounts.find((a) => a.game === "lol") ?? null;

export const useGameDataDashboard = () => {
  const baseData = MOCK_GAME_DATA_DASHBOARD;

  const defaultSelected = baseData.linkedAccounts[0]?.game ?? null;
  const [selectedGame, setSelectedGame] = useState<GameKey | null>(defaultSelected);
  const [activeTab, setActiveTab] = useState<DashboardTabKey>("matches");

  // pagination
  const [page] = useState<number>(baseData.lol.pagination.page);
  const pageSize = baseData.lol.pagination.pageSize;

  const lolAccount = useMemo(
    () => findLolAccount(baseData.linkedAccounts),
    [baseData.linkedAccounts]
  );

  const riotMeta = lolAccount?.meta?.riot ?? null;

  const lolQuery = useQuery({
    queryKey: ["gamedata", "lol", riotMeta?.riotId, page, pageSize],
    enabled: selectedGame === "lol" && !!riotMeta,
    queryFn: async () => {
      // 1) RiotId → PUUID
      const account = await riotApi.getPuuidByRiotId(riotMeta!.gameName, riotMeta!.tagLine);

      // 2) PUUID → Summoner
      const summoner = await riotApi.getSummonerByPuuid(account.puuid);

      // ✅ 여기서 핵심: summoner.id가 없으면 league 호출 스킵(400 방지)
      const summonerId = (summoner as any)?.id as string | undefined;

      if (!summonerId) {
        console.warn("[GameData] summoner.id가 없습니다. league 호출을 스킵합니다.", {
          account,
          summoner,
        });
      }

      // 3) SummonerId → League entries (없거나 403이면 [])
      const leagueEntries = await riotApi.getLeagueEntriesBySummonerId(summonerId);

      // 4) MatchIds → Match details
      const matchIds = await riotApi.getMatchIdsByPuuid(account.puuid, {
        start: (page - 1) * pageSize,
        count: pageSize,
      });

      const matchDetails = await Promise.all(matchIds.map((id) => riotApi.getMatchDetail(id)));

      const linkedProfile = buildLolLinkedProfile(account, summoner, leagueEntries);
      const aggregate = buildLolAggregateStats(matchDetails, account.puuid);
      const matches = buildLolMatchList(matchDetails, account.puuid);

      const totalPages = Math.max(1, baseData.lol.pagination.totalPages);

      const payload: GameDataDashboardData["lol"] = {
        linkedProfile,
        aggregate,
        matches,
        pagination: {
          page,
          pageSize,
          totalPages,
        },
      };

      return payload;
    },
  });

  /**
   * ✅ 연동된 게임 카드 accounts 값을 API 결과로 주입
   */
  const linkedAccounts = useMemo(() => {
    if (!lolAccount) return baseData.linkedAccounts;
    if (!lolQuery.data) return baseData.linkedAccounts;

    const lp = lolQuery.data.linkedProfile;
    const ag = lolQuery.data.aggregate;

    return baseData.linkedAccounts.map((a) => {
      if (a.game !== "lol") return a;

      return {
        ...a,
        accounts: [
          { label: "티어", value: lp.currentTier },
          { label: "주 포지션", value: lp.mainPosition },
          { label: "승률", value: `${ag.winRatePercent}%` },
        ],
      };
    });
  }, [baseData.linkedAccounts, lolAccount, lolQuery.data]);

  const data: GameDataDashboardData = useMemo(() => {
    if (lolQuery.data) {
      return {
        ...baseData,
        linkedAccounts,
        lol: lolQuery.data,
      };
    }
    return {
      ...baseData,
      linkedAccounts,
    };
  }, [baseData, linkedAccounts, lolQuery.data]);

  const view: DashboardView = useMemo(() => {
    if (!selectedGame) return { kind: "empty" };

    if (selectedGame === "lol") {
      if (!riotMeta) {
        return { kind: "lolError", message: "리그오브레전드 계정 정보(Riot ID)가 없습니다." };
      }

      if (lolQuery.isLoading) return { kind: "lolLoading" };

      if (lolQuery.isError) {
        const msg =
          lolQuery.error instanceof Error
            ? lolQuery.error.message
            : "일시적인 오류입니다. 다시 시도해 주세요.";
        return { kind: "lolError", message: msg };
      }

      if (lolQuery.data) return { kind: "lol", lol: lolQuery.data };

      return { kind: "lolLoading" };
    }

    return {
      kind: "placeholder",
      title: "준비중",
      subtitle: "현재 선택된 게임의 대시보드는 추후 업데이트 예정입니다.",
    };
  }, [selectedGame, riotMeta, lolQuery.isLoading, lolQuery.isError, lolQuery.error, lolQuery.data]);

  const actions = useMemo(
    () => ({
      onSelectGame: (game: GameKey) => {
        setSelectedGame(game);
        setActiveTab("matches");
      },
      onChangeTab: (tab: DashboardTabKey) => setActiveTab(tab),
    }),
    []
  );

  return {
    data,
    selectedGame,
    activeTab,
    view,
    actions,
  };
};