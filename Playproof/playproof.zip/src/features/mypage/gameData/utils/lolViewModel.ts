import type { AccountDto, LeagueEntryDto, MatchDto, SummonerDto } from "../api/riotApi";
import type { LolAggregateStats, LolLinkedProfile, LolMatchItem, MatchResult } from "../types/gameDataTypes";

const pickSoloQueue = (entries: LeagueEntryDto[]) =>
  entries.find((e) => e.queueType === "RANKED_SOLO_5x5") ?? null;

const formatTier = (tier: string, rank: string) => {
  if (!tier) return "Unranked";
  if (!rank) return tier;
  return `${tier[0] + tier.slice(1).toLowerCase()} ${rank}`;
};

const toPercent = (wins: number, losses: number) => {
  const total = wins + losses;
  if (total <= 0) return 0;
  return Math.round((wins / total) * 100);
};

const secondsToKoreanDuration = (sec: number) => {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}분 ${s}초`;
};

const kdaRatio = (k: number, d: number, a: number) => {
  const denom = d <= 0 ? 1 : d;
  const r = (k + a) / denom;
  return Math.round(r * 100) / 100;
};

const extractItemsCount = (p: MatchDto["info"]["participants"][number]) => {
  const items = [p.item0, p.item1, p.item2, p.item3, p.item4, p.item5, p.item6];
  return items.filter((x) => x && x !== 0).length;
};

/**
 * ✅ 닉네임/프로필 표시 우선순위
 * - 닉네임: account.gameName (+ tagLine)
 * - profileIconId: summoner.profileIconId (없으면 undefined)
 *
 * league가 403이어도, 닉네임/아이콘은 무조건 뜨게 만들기
 */
export const buildLolLinkedProfile = (
  account: AccountDto,
  summoner: SummonerDto | null,
  leagueEntries: LeagueEntryDto[]
): LolLinkedProfile => {
  const solo = pickSoloQueue(leagueEntries);

  const wins = solo?.wins ?? 0;
  const losses = solo?.losses ?? 0;
  const winRatePercent = toPercent(wins, losses);

  const summonerName = account.gameName; // ✅ 항상 존재
  const tagLine = account.tagLine;
  const riotId = `${account.gameName}#${account.tagLine}`;

  return {
    summonerName,
    tagLine,
    riotId,

    serverLabel: "Kr server",

    profileIconId: summoner?.profileIconId,
    summonerLevel: summoner?.summonerLevel,

    currentTier: solo ? formatTier(solo.tier, solo.rank) : "Unranked",
    mainPosition: "미정",
    winRatePercent,
  };
};

export const buildLolAggregateStats = (matches: MatchDto[], puuid: string): LolAggregateStats => {
  const recent = matches
    .map((m) => m.info.participants.find((p) => p.puuid === puuid))
    .filter(Boolean) as MatchDto["info"]["participants"][number][];

  let wins = 0;
  let losses = 0;

  let sumK = 0;
  let sumD = 0;
  let sumA = 0;

  const champCount = new Map<string, number>();
  const positionCount = new Map<string, number>();

  for (const p of recent) {
    if (p.win) wins += 1;
    else losses += 1;

    sumK += p.kills;
    sumD += p.deaths;
    sumA += p.assists;

    champCount.set(p.championName, (champCount.get(p.championName) ?? 0) + 1);
    if (p.teamPosition) positionCount.set(p.teamPosition, (positionCount.get(p.teamPosition) ?? 0) + 1);
  }

  const total = recent.length || 1;

  const mostChampions = [...champCount.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([name, games]) => ({ name, games }));

  return {
    wins,
    losses,
    winRatePercent: toPercent(wins, losses),
    avgKdaRatio: kdaRatio(sumK / total, sumD / total, sumA / total),
    avgKills: Math.round((sumK / total) * 10) / 10,
    avgDeaths: Math.round((sumD / total) * 10) / 10,
    avgAssists: Math.round((sumA / total) * 10) / 10,
    mostChampions,
  };
};

export const buildLolMatchList = (matches: MatchDto[], puuid: string): LolMatchItem[] => {
  return matches.map((m) => {
    const p = m.info.participants.find((x) => x.puuid === puuid);
    const win = p?.win ?? false;

    const result: MatchResult = win ? "win" : "lose";
    const k = p?.kills ?? 0;
    const d = p?.deaths ?? 0;
    const a = p?.assists ?? 0;

    return {
      id: m.metadata.matchId,
      result,
      queueLabel: "솔랭",
      durationText: secondsToKoreanDuration(m.info.gameDuration),
      kdaText: `${k}/${d}/${a}`,
      kdaRatioText: `${kdaRatio(k, d, a).toFixed(2)}:1 KDA`,
      pills: ["피해량", "시야점수", "CS", "골드"],
      itemsCount: p ? extractItemsCount(p) : 0,
    };
  });
};