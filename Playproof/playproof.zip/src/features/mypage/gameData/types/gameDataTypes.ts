export type GameKey = "lol" | "valorant" | "pubg" | "overwatch" | "steam";

/**
 * ✅ 연동된 게임 카드가 “API 호출에 필요한 식별자”를 함께 들고 있게 하기 위한 메타
 * - lol/valorant: Riot ID (gameName#tagLine)
 */
export type LinkedAccountMeta = {
  riot?: {
    gameName: string;
    tagLine: string;
    riotId: string; // `${gameName}#${tagLine}`
  };
};

export type LinkedAccount = {
  game: GameKey;
  title: string;
  subtitle?: string;
  accounts: Array<{
    label: string;
    value: string;
  }>;

  /** ✅ 훅에서만 사용(카드 UI는 몰라도 됨) */
  meta?: LinkedAccountMeta;
};

export type SiteUserProfile = {
  displayName: string;
  rankLabel: string;
  intro: string;
  noteLabel: string;
  noteValue: string;
};

export type LolLinkedProfile = {
  summonerName: string;
  tagLine?: string;
  riotId?: string;

  serverLabel: string;

  profileIconId?: number;
  summonerLevel?: number;

  currentTier: string;
  mainPosition: string;
  winRatePercent: number;
};

export type LolAggregateStats = {
  wins: number;
  losses: number;
  winRatePercent: number;
  avgKdaRatio: number;
  avgKills: number;
  avgDeaths: number;
  avgAssists: number;
  mostChampions: Array<{
    name: string;
    games: number;
  }>;
};

export type MatchResult = "win" | "lose";

export type LolMatchItem = {
  id: string;
  result: MatchResult;
  queueLabel: string;
  durationText: string;
  kdaText: string;
  kdaRatioText: string;
  pills: string[];
  itemsCount: number;
};

export type PaginationState = {
  page: number;
  pageSize: number;
  totalPages: number;
};

export type DashboardTabKey = "matches" | "tier";

export type GameDataDashboardData = {
  userProfile: SiteUserProfile;
  linkedAccounts: LinkedAccount[];
  lol: {
    linkedProfile: LolLinkedProfile;
    aggregate: LolAggregateStats;
    matches: LolMatchItem[];
    pagination: PaginationState;
  };
};