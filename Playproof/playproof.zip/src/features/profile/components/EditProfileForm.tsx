//src/features/profile/components/EditProfileForm.tsx
import React from 'react';

export const EditProfileForm: React.FC = () => {
  return (
    <section>
      <div>EditProfileForm</div>
    </section>
  );
};
