//src/features/profile/components/StatCard.tsx
import React from 'react';

export const StatCard: React.FC = () => {
  return (
    <section>
      <div>StatCard</div>
    </section>
  );
};
