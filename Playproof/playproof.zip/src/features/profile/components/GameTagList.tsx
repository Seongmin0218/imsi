//src/features/profile/components/GameTagList.tsx
import React from 'react';

export const GameTagList: React.FC = () => {
  return (
    <section>
      <div>GameTagList</div>
    </section>
  );
};
