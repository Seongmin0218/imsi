import axios from "axios";

// 공통: 캐시 끄기(개발 중 디버깅 안정성)
const noCacheHeaders = {
  "Cache-Control": "no-store",
  Pragma: "no-cache",
  Expires: "0",
};

// 1. Riot 한국 서버 (소환사, 티어 조회)
export const riotKrClient = axios.create({
  baseURL: "/api/riot",
  headers: noCacheHeaders,
});

// 2. Riot 아시아 서버 (매치, 계정 조회)
export const riotAsiaClient = axios.create({
  baseURL: "/api/riot-asia",
  headers: noCacheHeaders,
});

// 3. Nexon 클라이언트
export const nexonClient = axios.create({
  baseURL: "/api/nexon",
  headers: {
    "x-nxopen-api-key": import.meta.env.VITE_NEXON_API_KEY,
    ...noCacheHeaders,
  },
});

// 4. Steam 클라이언트
export const steamClient = axios.create({
  baseURL: "/api/steam",
  headers: noCacheHeaders,
});