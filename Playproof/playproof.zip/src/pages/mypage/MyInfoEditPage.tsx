//src/pages/mypage/MyInfoEditPage.tsx
import React from 'react';

const MyInfoEditPage: React.FC = () => {
  return (
    <main>
      <div>MyInfoEditPage</div>
    </main>
  );
};

export default MyInfoEditPage;
