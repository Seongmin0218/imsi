import { Card } from "@/components/ui/Card";
import { UserProfileCard } from "@/features/mypage/gameData/components/UserProfileCard";
import { LinkedAccountsRow } from "@/features/mypage/gameData/components/LinkedAccountsRow";
import { LolOverviewSection } from "@/features/mypage/gameData/components/lol/LolOverviewSection";
import { useGameDataDashboard } from "@/features/mypage/gameData/hooks/useGameDataDashboard";

const GameDataPage = () => {
  const dashboard = useGameDataDashboard();

  return (
    <div className="min-h-screen bg-white text-black">
      <main className="mx-auto w-full max-w-[1280px] px-6 py-10">
        <UserProfileCard profile={dashboard.data.userProfile} />

        <div className="mt-10">
          <div className="mb-4 text-sm font-semibold text-gray-700">연동된 게임 계정</div>

          <LinkedAccountsRow
            accounts={dashboard.data.linkedAccounts}
            selectedGame={dashboard.selectedGame}
            onSelectGame={dashboard.actions.onSelectGame}
          />
        </div>

        <div className="mt-8">
          {dashboard.view.kind === "lolLoading" && (
            <Card className="p-8">
              <div className="text-sm font-semibold text-gray-900">리그오브레전드 불러오는 중...</div>
              <div className="mt-2 text-xs text-gray-500">전적 데이터를 가져오고 있어요.</div>
            </Card>
          )}

          {dashboard.view.kind === "lolError" && (
            <Card className="p-8">
              <div className="text-sm font-semibold text-gray-900">일시적인 오류</div>
              <div className="mt-2 text-xs text-gray-500">{dashboard.view.message}</div>
            </Card>
          )}

          {dashboard.view.kind === "lol" && (
            <LolOverviewSection
              linkedProfile={dashboard.view.lol.linkedProfile}
              aggregate={dashboard.view.lol.aggregate}
              matches={dashboard.view.lol.matches}
              pagination={dashboard.view.lol.pagination}
              activeTab={dashboard.activeTab}
              onChangeTab={dashboard.actions.onChangeTab}
            />
          )}

          {dashboard.view.kind === "placeholder" && (
            <Card className="p-8">
              <div className="text-lg font-semibold">{dashboard.view.title}</div>
              <div className="mt-2 text-sm text-gray-600">{dashboard.view.subtitle}</div>
            </Card>
          )}

          {dashboard.view.kind === "empty" && (
            <Card className="p-8">
              <div className="text-sm text-gray-600">연동된 게임이 없습니다.</div>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
};

export default GameDataPage;