//src/pages/mypage/MyActivityPage.tsx
import React from 'react';

const MyActivityPage: React.FC = () => {
  return (
    <main>
      <div>MyActivityPage</div>
    </main>
  );
};

export default MyActivityPage;
