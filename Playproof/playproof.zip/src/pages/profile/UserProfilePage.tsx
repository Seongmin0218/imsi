//src/pages/profile/UserProfilePage.tsx
import React from 'react';

const UserProfilePage: React.FC = () => {
  return (
    <main>
      <div>UserProfilePage</div>
    </main>
  );
};

export default UserProfilePage;
