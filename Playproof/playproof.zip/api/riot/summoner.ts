export default async function handler(req: any, res: any) {
  if (req.method !== "GET") return res.status(405).json({ message: "Method Not Allowed" });

  const puuid = req.query.puuid;
  if (!puuid) return res.status(400).json({ message: "puuid is required" });

  const apiKey = process.env.RIOT_API_KEY;
  if (!apiKey) return res.status(500).json({ message: "Missing RIOT_API_KEY" });

  const url = `https://kr.api.riotgames.com/lol/summoner/v4/summoners/by-puuid/${encodeURIComponent(
    puuid
  )}`;

  const r = await fetch(url, { headers: { "X-Riot-Token": apiKey } });

  // ✅ 항상 JSON으로 반환 (axios에서 자동 파싱됨)
  const contentType = r.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const json = await r.json();
    return res.status(r.status).json(json);
  }

  // 혹시라도 JSON이 아니면 text로 받고 JSON 파싱 시도
  const text = await r.text();
  try {
    return res.status(r.status).json(JSON.parse(text));
  } catch {
    return res.status(r.status).json({ message: text });
  }
}