export default async function handler(req: any, res: any) {
  if (req.method !== "GET") return res.status(405).json({ message: "Method Not Allowed" });

  const gameName = req.query.gameName;
  const tagLine = req.query.tagLine;

  if (!gameName || !tagLine) {
    return res.status(400).json({ message: "gameName and tagLine are required" });
  }

  const apiKey = process.env.RIOT_API_KEY;
  if (!apiKey) return res.status(500).json({ message: "Missing RIOT_API_KEY" });

  const url = `https://asia.api.riotgames.com/riot/account/v1/accounts/by-riot-id/${encodeURIComponent(
    gameName
  )}/${encodeURIComponent(tagLine)}`;

  const r = await fetch(url, { headers: { "X-Riot-Token": apiKey } });

  const contentType = r.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const json = await r.json();
    return res.status(r.status).json(json);
  }

  const text = await r.text();
  try {
    return res.status(r.status).json(JSON.parse(text));
  } catch {
    return res.status(r.status).json({ message: text });
  }
}